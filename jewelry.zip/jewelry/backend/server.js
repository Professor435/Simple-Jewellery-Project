require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(express.json());

// MySQL connection
const db = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'mydb'
});

db.connect(err => {
  if (err) {
    console.error(" DB connection error:", err.stack);
    return;
  }
  console.log(" Connected to MySQL database:", process.env.DB_NAME || 'mydb');
});

// Auth routes
const authRouter = express.Router();
authRouter.post('/register', async (req, res) => {
  const { fullname, email, phone, password } = req.body;

  if (!fullname || !email || !phone || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }

  const checkSql = "SELECT * FROM users WHERE email = ? OR phone = ?";
  db.query(checkSql, [email, phone], async (checkErr, results) => {
    if (checkErr) {
      return res.status(500).json({ message: "Error checking user", error: checkErr });
    }

    if (results.length > 0) {
      return res.status(400).json({ message: "Email or phone already registered" });
    }

    try {
      const hashedPassword = await bcrypt.hash(password, 10);

      // Assuming 'id' is AUTO_INCREMENT and 'created_at' has a default timestamp
      const insertSql = "INSERT INTO users (fullname, email, phone, password) VALUES (?, ?, ?, ?)";
      db.query(insertSql, [fullname, email, phone, hashedPassword], (err, result) => {
        if (err) {
          return res.status(500).json({ message: "Error registering", error: err });
        }
        return res.status(200).json({ message: "Registration successful" });
      });

    } catch (hashErr) {
      return res.status(500).json({ message: "Server error", error: hashErr });
    }
  });
});


// Login route
authRouter.post('/login', (req, res) => {
  const { identifier, password } = req.body;

  if (!identifier || !password) {
    return res.status(400).json({ message: "Email/Phone and password are required" });
  }

  const sql = "SELECT * FROM users WHERE email = ? OR phone = ?";
  db.query(sql, [identifier, identifier], async (err, results) => {
    if (err) return res.status(500).json({ message: "DB error", error: err });

    if (results.length === 0) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const user = results[0];

    try {
      const match = await bcrypt.compare(password, user.password);
      if (!match) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Generate JWT token
      const token = jwt.sign(
        { id: user.id, email: user.email },
        process.env.JWT_SECRET || 'your_jwt_secret',
        { expiresIn: '1h' }
      );

      return res.status(200).json({
        message: "Login successful",
        user: {
          id: user.id,
          fullname: user.fullname,
          email: user.email,
          phone: user.phone
        },
        token
      });
    } catch (compareErr) {
      return res.status(500).json({ message: "Server error", error: compareErr });
    }
  });
});

app.use('/api/auth', authRouter);













// ✅ GET all cart items for a user
app.get("/api/cart_items/:userId", (req, res) => {
  const { userId } = req.params;
  const sql = "SELECT * FROM cart_items WHERE user_id = ?";
  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).json({ error: "Error fetching cart items." });
    res.json(results);
  });
});

// ✅ POST: Add item to cart
app.post("/api/cart_items", (req, res) => {
  const { user_id, product_id, quantity } = req.body;
  if (!user_id || !product_id || !quantity)
    return res.status(400).json({ error: "Missing required fields." });

  const sql = "INSERT INTO `cart_items`(`id`, `user_id`, `product_id`, `quantity`, `price_per_unit`, `created_at`, `updated_at`) VALUES (?,?,?,?,?,?,?)";
  db.query(sql, [user_id, product_id, quantity], (err, result) => {
    if (err) return res.status(500).json({ error: "Error adding to cart." });
    res.json({ message: "Item added", id: result.insertId });
  });
});

// ✅ PUT: Update quantity
app.put("/api/cart_items/:userId/update", (req, res) => {
  const { userId } = req.params;
  const { productId, quantity } = req.body;
  if (!productId || typeof quantity !== "number" || quantity < 1)
    return res.status(400).json({ error: "Invalid data" });

  const sql = "UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?";
  db.query(sql, [quantity, userId, productId], (err, result) => {
    if (err) return res.status(500).json({ error: "Error updating quantity." });
    if (result.affectedRows === 0) return res.status(404).json({ error: "Item not found." });
    res.json({ message: "Updated successfully." });
  });
});

// ✅ DELETE: Remove item
app.delete("/api/cart_items/:userId/remove/:productId", (req, res) => {
  const { userId, productId } = req.params;
  const sql = "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?";
  db.query(sql, [userId, productId], (err, result) => {
    if (err) return res.status(500).json({ error: "Error deleting item." });
    if (result.affectedRows === 0) return res.status(404).json({ error: "Item not found." });
    res.json({ message: "Item removed." });
  });
});




































// Test route
app.get("/", (req, res) => {
  db.query("SELECT * FROM users", (err, data) => {
    if (err) return res.status(500).json({ message: "DB error", error: err });
    res.json(data);
  });
});

// Start server
app.listen(PORT, () => {
  console.log(` Server running on http://localhost:${PORT}`);
});


