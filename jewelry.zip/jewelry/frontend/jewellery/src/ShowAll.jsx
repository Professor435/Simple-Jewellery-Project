import React, { useEffect, useRef } from "react";
import "./ShowAll.css";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Accordion from "react-bootstrap/Accordion";

function ShowAll() {
  useEffect(() => {
    window.toggleSidebar = () => {
      document.getElementById("sidebar").classList.toggle("open");
    };

    const handleClickOutside = (event) => {
      const sidebar = document.getElementById("sidebar");
      const isClickInsideSidebar = sidebar.contains(event.target);
      const isMenuIcon = event.target.closest(".menu-icon");
      const isMenuText = event.target.closest(".menu");

      if (
        !isClickInsideSidebar &&
        !isMenuIcon &&
        !isMenuText &&
        sidebar.classList.contains("open")
      ) {
        sidebar.classList.remove("open");
      }
    };

    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  const products = [
    {
      name: "Gold Diamond Ring",
      description: "Elegant 18K gold ring with real diamonds.",
      price: 18500,
      image: "/images/ring1.jpg",
    },
    {
      name: "Pearl Necklace",
      description: "Classic white pearl necklace for formal occasions.",
      price: 13200,
      image: "/images/necklace1.jpg",
    },
    {
      name: "Silver Bracelet",
      description: "Handcrafted silver bracelet with fine detailing.",
      price: 9500,
      image: "/images/bracelet1.jpg",
    },
    {
      name: "Gemstone Earrings",
      description: "Studded gemstone earrings for everyday glam.",
      price: 7700,
      image: "/images/earrings1.jpg",
    },
  ];

  return (
    <>
      <div className="top-bar">Call Us / WhatsApp: 0312-456-7890</div>

      <div className="navbar">
        <div className="menu-icon mobile-only" onClick={window.toggleSidebar}>☰</div>
        <div className="logo">
          JEWELRY<span>HUB</span>
        </div>
        <div className="menu desktop-only" onClick={window.toggleSidebar}>
          MENU
        </div>

        <div className="search-bar">
          <input type="text-white" placeholder="Search for jewelry..." />
          <i className="fas fa-search"></i>
        </div>

        <div className="right-icons">
          <Link to="/cart" style={{ fontSize: "24px", textDecoration: "none" }}>🛒</Link>
          <Link to="/auth">LOGIN / REGISTER</Link>
        </div>
      </div>

      <div className="sidebar" id="sidebar">
        <div className="close-btn" onClick={window.toggleSidebar}>
          <span>&#x2715; Close</span>
        </div>
        <input type="text-white" placeholder="Search..." />

        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0">
            <Accordion.Header>Categories</Accordion.Header>
            <Accordion.Body>
              <Link to="/rings">Rings</Link><br />
              <Link to="/necklaces">Necklaces</Link><br />
              <Link to="/bracelets">Bracelets</Link><br />
              <Link to="/earrings">Earrings</Link><br />
              <Link to="/sets">Jewelry Sets</Link>
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="1">
            <Accordion.Header>Collections</Accordion.Header>
            <Accordion.Body>
              <Link to="/new">New Arrivals</Link><br />
              <Link to="/bestsellers">Best Sellers</Link><br />
              <Link to="/sale">On Sale</Link>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      </div>


      <div className="container py-5">
        <h2 className="text-center mb-4">Popular Jewelry</h2>
        <div className="row g-4">
          {products.map((product, index) => (
            <div key={index} className="col-md-3 col-sm-6">
              <div className="card h-100 shadow-sm">
                <img src={product.image} className="card-img-top" alt={product.name} style={{ height: "200px", objectFit: "cover" }} />
                <div className="card-body d-flex flex-column justify-content-between">
                  <h5 className="card-title">{product.name}</h5>
                  <p className="card-text">{product.description}</p>
                  <p className="text-primary fw-bold">PKR {product.price}</p>
                  <div className="d-grid gap-2">
                    <button className="btn btn-warning" onClick={() => window.addToCart(product.name, product.price, 1)}>🛒 Add to Cart</button>
                    <Link to="/payment" className="btn btn-outline-dark">⚡ Buy Now</Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mobile-nav" id="mobileNav">
        <Link to="/rings"><div>💍<br />Rings</div></Link>
        <Link to="/cart"><div>🛒<br />Cart</div></Link>
        <Link to="/auth"><div>👤<br />Account</div></Link>
      </div>

      <div className="page-wrapper">
        <footer>
          <div className="container">
            <div className="footer-about">
              <h3>About JewelryHub</h3>
              <p>Your trusted source for luxury and stylish jewelry.</p>
            </div>
            <div className="footer-links">
              <h3>Quick Links</h3>
              <ul>
                <li><Link to="/shop">Shop</Link></li>
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/contact">Contact</Link></li>
              </ul>
            </div>
            <div className="footer-contact">
              <h3>Contact Us</h3>
              <p>Email: info@jewelryhub.com</p>
              <p>Phone: 0312-456-7890</p>
              <p>Address: 456 Gold Lane, Glamour City</p>
            </div>
            <div className="newsletter">
              <h3>Newsletter</h3>
              <form onSubmit={(e) => { e.preventDefault(); alert("Subscribed!"); }}>
                <input type="email" placeholder="Your email" required />
                <button type="submit">Subscribe</button>
              </form>
            </div>
          </div>
          <small>&copy; 2025 JewelryHub. All rights reserved.</small>
        </footer>
      </div>
    </>
  );
}

export default ShowAll;
