import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AuthForm from './AuthForm';
import Cart from "./Cart"; // Your Cart page
import ShowAll from "./ShowAll"; // Product listing or main component

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ShowAll />} />  {/* This matches "/" */}
        <Route path="/cart" element={<Cart />} />
        <Route path="/auth" element={<AuthForm />} />
        {/* Add other routes as needed */}
      </Routes>
    </Router>
  );
}

export default App;
