import React, { useState, useEffect } from "react";

const API_BASE = "http://localhost:8080/api/cart_items";
const USER_ID = 1;

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [formData, setFormData] = useState({ product_id: "", quantity: 1 });
  const [editQuantities, setEditQuantities] = useState({});

  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      const res = await fetch(`${API_BASE}/${USER_ID}`);
      const data = await res.json();
      setCartItems(data);

      const initialQuantities = {};
      data.forEach((item) => {
        initialQuantities[item.product_id] = item.quantity;
      });
      setEditQuantities(initialQuantities);
    } catch (err) {
      console.error("Error fetching cart items:", err);
    }
  };

  const handleAddToCart = async () => {
    try {
      const res = await fetch(API_BASE, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: USER_ID,
          product_id: parseInt(formData.product_id),
          quantity: parseInt(formData.quantity),
        }),
      });
      if (!res.ok) throw new Error("Add failed");
      fetchCartItems();
      setFormData({ product_id: "", quantity: 1 });
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateQuantity = async (product_id) => {
    try {
      const res = await fetch(`${API_BASE}/${USER_ID}/update`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product_id,
          quantity: parseInt(editQuantities[product_id]),
        }),
      });
      if (!res.ok) throw new Error("Update failed");
      fetchCartItems();
    } catch (err) {
      console.error(err);
    }
  };

  const handleRemoveItem = async (product_id) => {
    try {
      const res = await fetch(`${API_BASE}/${USER_ID}/remove/${product_id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Delete failed");
      fetchCartItems();
    } catch (err) {
      console.error(err);
    }
  };

  const calculateTotalPrice = (price, quantity) => {
    return (price * quantity).toFixed(2);
  };

  const grandTotal = cartItems.reduce((sum, item) => {
    return sum + item.price * item.quantity;
  }, 0);

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Your Jewelry Cart</h1>

      <div className="mb-6 space-y-2">
        <input
          type="number"
          placeholder="Jewelry Item ID"
          value={formData.product_id}
          onChange={(e) =>
            setFormData({ ...formData, product_id: e.target.value })
          }
          className="border p-2 w-full"
        />
        <input
          type="number"
          placeholder="Quantity"
          value={formData.quantity}
          onChange={(e) =>
            setFormData({ ...formData, quantity: e.target.value })
          }
          className="border p-2 w-full"
        />
        <button
          onClick={handleAddToCart}
          className="bg-purple-600 text-white w-full p-2 rounded hover:bg-purple-700"
        >
          Add Jewelry to Cart
        </button>
      </div>

      <h2 className="text-xl font-semibold mb-2">Your Selected Items</h2>
      <ul className="space-y-4">
        {cartItems.map((item) => (
          <li key={item.id} className="border p-3 rounded shadow-sm">
            <p><strong>Jewelry ID:</strong> {item.product_id}</p>
            <p><strong>Quantity:</strong> {item.quantity}</p>
             <p>Price Per Unit: {item.price ? item.price.toFixed(2) : "0.00"}</p>
            <p><strong>Total:</strong> ${calculateTotalPrice(item.price, item.quantity)}</p>

            <input
              type="number"
              value={editQuantities[item.product_id] || item.quantity}
              onChange={(e) =>
                setEditQuantities({
                  ...editQuantities,
                  [item.product_id]: e.target.value,
                })
              }
              className="border px-2 py-1 w-20 mt-1"
            />

            <div className="flex gap-2 mt-3">
              <button
                onClick={() => handleUpdateQuantity(item.product_id)}
                className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600"
              >
                Update
              </button>
              <button
                onClick={() => handleRemoveItem(item.product_id)}
                className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
              >
                Remove
              </button>
            </div>

            <p className="text-sm text-gray-500 mt-2">
              Last updated: {new Date(item.updated_at).toLocaleString()}
            </p>
          </li>
        ))}
      </ul>

      {cartItems.length > 0 && (
        <div className="mt-6 text-right text-xl font-bold text-purple-800">
          Grand Total: ${grandTotal.toFixed(2)}
        </div>
      )}
    </div>
  );
};

export default Cart;
